const Router = require('@koa/router')
const logsController = require('./controller')
const { authMiddleware } = require('../../middlewares/auth.middleware')
const { requirePermission } = require('../../middlewares/checkPermission')

const router = new Router({ prefix: '/logs' })

/**
 * @swagger
 * /logs:
 *   get:
 *     tags:
 *       - logs
 *     summary: 获取日志列表
 *     description: 获取聊天日志列表，默认返回所有日期的日志
 *     parameters:
 *       - name: date
 *         in: query
 *         schema:
 *           type: string
 *         description: 指定日期 (YYYY-MM-DD)
 *       - name: limit
 *         in: query
 *         schema:
 *           type: integer
 *           default: 50
 *         description: 返回条数 (1-1000)
 *       - name: keyword
 *         in: query
 *         schema:
 *           type: string
 *         description: 搜索关键词
 *       - name: status
 *         in: query
 *         schema:
 *           type: string
 *           enum: [success, error]
 *         description: 状态筛选
 *     responses:
 *       200:
 *         description: 成功
 */
router.get('/', logsController.getLogs.bind(logsController))

/**
 * @swagger
 * /logs/today:
 *   get:
 *     tags:
 *       - logs
 *     summary: 获取今日日志
 *     parameters:
 *       - name: limit
 *         in: query
 *         schema:
 *           type: integer
 *           default: 50
 *       - name: keyword
 *         in: query
 *         schema:
 *           type: string
 *       - name: status
 *         in: query
 *         schema:
 *           type: string
 *       - name: session_id
 *         in: query
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: 成功
 */
router.get('/today', logsController.getTodayLogs.bind(logsController))

/**
 * @swagger
 * /logs/trace/{trace_id}:
 *   get:
 *     tags:
 *       - logs
 *     summary: 通过 Trace ID 查询日志
 *     parameters:
 *       - name: trace_id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: 成功
 */
router.get('/trace/:trace_id', logsController.getTraceLog.bind(logsController))

/**
 * @swagger
 * /logs/session/{session_id}:
 *   get:
 *     tags:
 *       - logs
 *     summary: 获取会话日志
 *     parameters:
 *       - name: session_id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *       - name: limit
 *         in: query
 *         schema:
 *           type: integer
 *           default: 50
 *     responses:
 *       200:
 *         description: 成功
 */
router.get('/session/:session_id', logsController.getSessionLogs.bind(logsController))

/**
 * @swagger
 * /logs/dates:
 *   get:
 *     tags:
 *       - logs
 *     summary: 获取可用日期列表
 *     responses:
 *       200:
 *         description: 成功
 */
router.get('/dates', logsController.getAvailableDates.bind(logsController))

/**
 * @swagger
 * /logs/stats:
 *   get:
 *     tags:
 *       - logs
 *     summary: 获取统计信息
 *     parameters:
 *       - name: date
 *         in: query
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: 成功
 */
router.get('/stats', logsController.getStats.bind(logsController))

/**
 * 获取 PM2 日志（需要管理员权限）
 */
router.get('/pm2', authMiddleware(), requirePermission('log:read'), logsController.getPm2Logs.bind(logsController))

/**
 * 获取 PM2 日志文件列表（公开接口，用于 smithyuyi001 页面）
 */
router.get('/pm2/files', logsController.getPm2LogFiles.bind(logsController))

/**
 * 获取 PM2 日志详情（公开接口，用于 smithyuyi001 页面，页面本身有密码验证）
 */
router.get('/pm2/detail', logsController.getPm2Logs.bind(logsController))

/**
 * 清空 PM2 日志（需要管理员权限）
 */
router.post('/pm2/clear', authMiddleware(), requirePermission('log:delete'), logsController.clearPm2Logs.bind(logsController))

module.exports = router
