const fs = require('fs')
const path = require('path')
const dayjs = require('dayjs')
const config = require('../../config')
const { calculateSuccessRate, calculateAverage } = require('../../utils/helpers')

const LOG_DIR = path.join(process.cwd(), config.log.dir)

class LogsService {
  /**
   * 获取日志列表
   * @param {Object} params - 查询参数
   * @param {string} [params.date] - 日期
   * @param {number} [params.limit=50] - 限制数量
   * @param {string} [params.keyword] - 关键词
   * @param {string} [params.status] - 状态
   * @returns {Promise<Object>} 日志数据
   */
  async getLogs(params) {
    if (!fs.existsSync(LOG_DIR)) {
      return { count: 0, logs: [], message: '暂无日志' }
    }

    const { date, limit = 50, keyword, status } = params
    let allLogs = []
    let queryDates = []

    if (date) {
      const logFile = path.join(LOG_DIR, `chat_${date}.jsonl`)
      if (fs.existsSync(logFile)) {
        allLogs = this.readLogFile(logFile)
      }
      queryDates = [date]
    } else {
      const logFiles = this.getLogFiles()
      for (const logFile of logFiles) {
        const dateStr = path.basename(logFile, '.jsonl').replace('chat_', '')
        queryDates.push(dateStr)
        allLogs = allLogs.concat(this.readLogFile(logFile))
      }
    }

    let filteredLogs = allLogs
    if (status) {
      filteredLogs = filteredLogs.filter((log) => log.status === status)
    }
    if (keyword) {
      const lowerKeyword = keyword.toLowerCase()
      filteredLogs = filteredLogs.filter((log) => {
        const searchText = (log.input_preview + log.output_preview).toLowerCase()
        return searchText.includes(lowerKeyword)
      })
    }
    // 按时间倒序排序（最新的在前）
    filteredLogs.sort((a, b) => new Date(b.time) - new Date(a.time))

    const resultLogs = filteredLogs.slice(0, limit)

    return {
      count: resultLogs.length,
      dates: queryDates,
      logs: resultLogs,
    }
  }

  /**
   * 获取今日日志
   * @param {Object} params - 查询参数
   * @returns {Promise<Object>} 今日日志
   */
  async getTodayLogs(params) {
    const today = dayjs().format('YYYY-MM-DD')
    const logFile = path.join(LOG_DIR, `chat_${today}.jsonl`)

    if (!fs.existsSync(logFile)) {
      return { count: 0, logs: [], message: '今日暂无日志' }
    }

    let logs = this.readLogFile(logFile)

    const { limit = 50, keyword, status, session_id } = params
    if (status) {
      logs = logs.filter((log) => log.status === status)
    }
    if (session_id) {
      logs = logs.filter((log) => log.session_id === session_id)
    }
    if (keyword) {
      const lowerKeyword = keyword.toLowerCase()
      logs = logs.filter((log) => {
        const searchText = (log.input_preview + log.output_preview).toLowerCase()
        return searchText.includes(lowerKeyword)
      })
    }

    return {
      count: logs.length,
      logs: logs.slice(0, limit),
    }
  }

  /**
   * 通过 Trace ID 查询日志
   * @param {string} traceId - 追踪 ID
   * @returns {Promise<Object>} 日志或错误
   */
  async getTraceLog(traceId) {
    const today = dayjs().format('YYYY-MM-DD')
    const logFile = path.join(LOG_DIR, `chat_${today}.jsonl`)

    if (!fs.existsSync(logFile)) {
      return { error: '今日暂无日志' }
    }

    const logs = this.readLogFile(logFile)
    const log = logs.find((l) => l.trace_id === traceId)

    return log || { error: `未找到 trace_id: ${traceId}` }
  }

  /**
   * 获取会话日志
   * @param {string} sessionId - 会话 ID
   * @param {number} [limit=50] - 限制数量
   * @returns {Promise<Object>} 会话日志
   */
  async getSessionLogs(sessionId, limit = 50) {
    const today = dayjs().format('YYYY-MM-DD')
    const logFile = path.join(LOG_DIR, `chat_${today}.jsonl`)

    if (!fs.existsSync(logFile)) {
      return { count: 0, session_id: sessionId, logs: [] }
    }

    const logs = this.readLogFile(logFile).filter((log) => log.session_id === sessionId)

    return {
      count: logs.length,
      session_id: sessionId,
      logs: logs.slice(0, limit),
    }
  }

  /**
   * 获取可用日期列表
   * @returns {Promise<Object>} 日期列表
   */
  async getAvailableDates() {
    if (!fs.existsSync(LOG_DIR)) {
      return { dates: [] }
    }

    const dates = this.getLogFiles().map((file) =>
      path.basename(file, '.jsonl').replace('chat_', ''),
    )

    return { dates }
  }

  /**
   * 获取统计信息
   * @param {string} [date] - 日期（不传则统计所有日志）
   * @returns {Promise<Object>} 统计数据
   */
  async getStats(date) {
    // 如果指定了日期，只查询该日期的日志
    if (date) {
      const logFile = path.join(LOG_DIR, `chat_${date}.jsonl`)

      if (!fs.existsSync(logFile)) {
        return {
          date: date,
          total: 0,
          success: 0,
          failed: 0,
          success_rate: 0,
          avg_duration: 0,
          total_tokens: {
            input: 0,
            output: 0,
            total: 0,
          },
        }
      }

      const logs = this.readLogFile(logFile)
      return this.calculateStats(logs, date)
    }

    // 如果没有指定日期，查询所有日志文件的总和
    const logFiles = this.getLogFiles()
    let allLogs = []

    for (const logFile of logFiles) {
      const logs = this.readLogFile(logFile)
      allLogs = allLogs.concat(logs)
    }

    return this.calculateStats(allLogs, 'all')
  }

  /**
   * 计算统计数据
   * @private
   * @param {Array} logs - 日志数组
   * @param {string} date - 日期标识
   * @returns {Object} 统计数据
   */
  calculateStats(logs, date) {
    const total = logs.length
    const success = logs.filter((log) => log.status === 'success').length
    const failed = total - success
    const durations = logs.map((log) => log.duration)
    const inputTokens = logs.reduce((sum, log) => sum + (log.tokens?.input || 0), 0)
    const outputTokens = logs.reduce((sum, log) => sum + (log.tokens?.output || 0), 0)

    return {
      date: date,
      total,
      success,
      failed,
      success_rate: calculateSuccessRate(success, total),
      avg_duration: calculateAverage(durations),
      total_tokens: {
        input: inputTokens,
        output: outputTokens,
        total: inputTokens + outputTokens,
      },
    }
  }

  /**
   * 读取日志文件
   * @private
   * @param {string} filePath - 文件路径
   * @returns {Array} 日志数组
   */
  readLogFile(filePath) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8')
      return content
        .split('\n')
        .filter((line) => line.trim())
        .map((line) => JSON.parse(line))
    } catch {
      return []
    }
  }

  /**
   * 获取日志文件列表
   * @private
   * @returns {Array} 文件路径数组
   */
  getLogFiles() {
    try {
      return fs
        .readdirSync(LOG_DIR)
        .filter((file) => file.startsWith('chat_') && file.endsWith('.jsonl'))
        .sort()
        .reverse()
        .map((file) => path.join(LOG_DIR, file))
    } catch {
      return []
    }
  }

  /**
   * 获取 PM2 日志详情
   * @param {Object} params - 查询参数
   * @param {string} params.type - 日志类型（out 或 error）
   * @param {number} params.lines - 返回行数
   * @param {string} params.process - 进程名称
   * @returns {Promise<Object>} 日志内容
   */
  async getPm2Logs(params) {
    try {
      const { type, lines, process } = params
      
      // ✅ 使用与 getPm2LogFiles 相同的目录
      const logsDir = '/www/wwwroot/api.yumanyi.top/logs'
      
      if (!fs.existsSync(logsDir)) {
        return {
          success: false,
          message: '日志目录不存在',
          logs: '',
        }
      }
      
      // 构造日志文件名
      // process: 'ai-api', type: 'out' => 'ai-api-out.log'
      // 或者前端传的是 'api-out', 'api-error' 等格式
      let fileName = ''
      
      // 尝试多种文件名格式
      const possibleNames = [
        `${process}-${type}.log`,      // ai-api-out.log
        `${process}-${type}`,           // 不带 .log
        `${process.replace('api-', '')}-${type.replace('api-', '')}.log`,  // 去除 api- 前缀
      ]
      
      let filePath = null
      for (const name of possibleNames) {
        const testPath = path.join(logsDir, name)
        if (fs.existsSync(testPath)) {
          filePath = testPath
          break
        }
      }
      
      if (!filePath) {
        // 列出目录中所有的 .log 文件帮助调试
        const allFiles = fs.readdirSync(logsDir).filter(f => f.endsWith('.log'))
        return {
          success: false,
          message: `日志文件不存在，尝试的文件名: ${possibleNames.join(', ')}，目录中的文件: ${allFiles.join(', ')}`,
          logs: '',
        }
      }
      
      // 读取日志文件最后N行
      const content = fs.readFileSync(filePath, 'utf-8')
      const allLines = content.split('\n').filter(line => line.trim())
      const lastLines = allLines.slice(-lines)
      
      return {
        success: true,
        logs: lastLines.join('\n'),
        totalLines: allLines.length,
        returnedLines: lastLines.length,
      }
    } catch (error) {
      console.error('获取 PM2 日志失败:', error)
      return {
        success: false,
        message: `获取日志失败: ${error.message}`,
        logs: '',
      }
    }
  }

  /**
   * 清空 PM2 日志
   * @returns {Promise<Object>} 清空结果
   */
  async clearPm2Logs() {
    try {
      const pm2Home = process.env.PM2_HOME || path.join(require('os').homedir(), '.pm2')
      const logsDir = path.join(pm2Home, 'logs')

      if (!fs.existsSync(logsDir)) {
        return {
          success: false,
          message: 'PM2 日志目录不存在',
        }
      }

      // 清空所有 .log 文件
      const files = fs.readdirSync(logsDir).filter((file) => file.endsWith('.log'))
      let clearedCount = 0

      for (const file of files) {
        const filePath = path.join(logsDir, file)
        fs.writeFileSync(filePath, '')
        clearedCount++
      }

      // 同时清空项目的 logs 目录
      const projectLogsDir = path.join(process.cwd(), 'logs')
      if (fs.existsSync(projectLogsDir)) {
        const projectFiles = fs.readdirSync(projectLogsDir)
        for (const file of projectFiles) {
          const filePath = path.join(projectLogsDir, file)
          const stats = fs.statSync(filePath)
          if (stats.isFile()) {
            fs.writeFileSync(filePath, '')
            clearedCount++
          }
        }
      }

      return {
        success: true,
        message: `成功清空 ${clearedCount} 个日志文件`,
        clearedCount: clearedCount,
      }
    } catch (error) {
      console.error('清空 PM2 日志失败:', error)
      return {
        success: false,
        message: `清空日志失败: ${error.message}`,
      }
    }
  }

  /**
   * 获取 PM2 日志文件列表
   * @returns {Promise<Object>} 日志文件列表
   */
  async getPm2LogFiles() {
    try {
      // ✅ 优先使用配置的路径，如果没有则使用默认 PM2 路径
      let logsDir
      
      // 尝试多个可能的路径
      const possiblePaths = [
        '/www/wwwroot/api.yumanyi.top/logs',  // 服务器路径
        path.join(process.cwd(), 'logs'),      // 项目 logs 目录
        path.join(require('os').homedir(), '.pm2', 'logs'), // PM2 默认路径
      ]
      
      // 找到第一个存在的路径
      for (const testPath of possiblePaths) {
        if (fs.existsSync(testPath)) {
          logsDir = testPath
          break
        }
      }
      
      if (!logsDir) {
        return { success: false, message: '日志目录不存在', files: [] };
      }
      
      console.log('📂 使用日志目录:', logsDir);

      // 读取文件（同时读取 .log 文件）
      const allFiles = fs.readdirSync(logsDir);
      const files = allFiles.filter((file) => file.endsWith('.log'));
      console.log('📂 找到的 .log 文件:', files);
      console.log('📂 目录中所有文件:', allFiles);
      
      const logFiles = [];
      for (const file of files) {
        const filePath = path.join(logsDir, file);
        const stats = fs.statSync(filePath);
        
        // 解析 ai-api-out.log -> process: ai, type: api-out
        const fileName = file.replace('.log', '');
        const parts = fileName.split('-');
        
        // 智能解析文件名
        let process, type
        if (parts.length >= 2) {
          // ai-api-out -> process: ai, type: api-out
          // ai-api-error -> process: ai, type: api-error
          process = parts[0] || 'unknown'
          type = parts.slice(1).join('-') || 'unknown'
        } else {
          process = 'unknown'
          type = fileName
        }

        logFiles.push({
          process,
          type,
          size: stats.size,
          // ✅ 使用 dayjs 转换为本地时间（中国时区 UTC+8）
          modifiedTime: dayjs(stats.mtime).format('YYYY-MM-DD HH:mm:ss'),
          fileName: file,
        });
      }

      logFiles.sort((a, b) => new Date(b.modifiedTime) - new Date(a.modifiedTime));

      return { success: true, files: logFiles, count: logFiles.length };
    } catch (error) {
      console.error(' 获取日志列表失败:', error);
      return { success: false, message: error.message, files: [] };
    }
  }

  /**
   * 读取 PM2 默认日志目录
   * @private
   */
  readPm2Logs(logsDir) {
    const files = fs.readdirSync(logsDir).filter((file) => file.endsWith('.log'))
    const logFiles = []

    for (const file of files) {
      const filePath = path.join(logsDir, file)
      const stats = fs.statSync(filePath)
      
      // 解析文件名：{process}-{type}.log
      const fileName = file.replace('.log', '')
      const lastDashIndex = fileName.lastIndexOf('-')
      const process = lastDashIndex > 0 ? fileName.substring(0, lastDashIndex) : fileName
      const type = lastDashIndex > 0 ? fileName.substring(lastDashIndex + 1) : 'unknown'

      logFiles.push({
        process,
        type,
        size: stats.size,
        modifiedTime: stats.mtime.toISOString().replace('T', ' ').substring(0, 19),
        fileName: file,
      })
    }

    // 按修改时间倒序排序
    logFiles.sort((a, b) => new Date(b.modifiedTime) - new Date(a.modifiedTime))

    return {
      success: true,
      files: logFiles,
      count: logFiles.length,
    }
  }

  /**
   * 读取项目日志目录
   * @private
   */
  readProjectLogs(projectLogsDir) {
    const files = fs.readdirSync(projectLogsDir).filter((file) => file.endsWith('.log'))
    const logFiles = []

    for (const file of files) {
      const filePath = path.join(projectLogsDir, file)
      const stats = fs.statSync(filePath)
      
      // 解析文件名：ai-api-{type}.log 或 chat_{date}.jsonl
      let process = 'unknown'
      let type = 'unknown'
      
      if (file.startsWith('ai-api-')) {
        process = 'ai-api'
        type = file.replace('ai-api-', '').replace('.log', '')
      } else if (file.startsWith('chat_')) {
        process = 'chat'
        type = file.replace('chat_', '').replace('.jsonl', '')
      } else {
        const fileName = file.replace(/\.(log|jsonl)$/, '')
        const lastDashIndex = fileName.lastIndexOf('-')
        process = lastDashIndex > 0 ? fileName.substring(0, lastDashIndex) : fileName
        type = lastDashIndex > 0 ? fileName.substring(lastDashIndex + 1) : 'unknown'
      }

      logFiles.push({
        process,
        type,
        size: stats.size,
        modifiedTime: stats.mtime.toISOString().replace('T', ' ').substring(0, 19),
        fileName: file,
      })
    }

    // 按修改时间倒序排序
    logFiles.sort((a, b) => new Date(b.modifiedTime) - new Date(a.modifiedTime))

    return {
      success: true,
      files: logFiles,
      count: logFiles.length,
      note: '从项目 logs 目录读取',
    }
  }
}

module.exports = new LogsService()
