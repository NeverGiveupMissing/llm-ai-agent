/**
 * 数据库管理 Service
 * 路径：koa2/src/modules/database/service.js
 */

const pool = require('../../config/db')
const operationLogger = require('../../middlewares/operation-logger')
const fs = require('fs')
const path = require('path')
const { exec } = require('child_process')
const archiver = require('archiver')
const util = require('util')
const execPromise = util.promisify(exec)

/**
 * 执行 SQL 语句（包含安全检查）
 * @param {string} sql - SQL 语句
 * @param {string} userId - 用户ID
 * @param {string} username - 用户名
 * @param {string} ipAddress - IP地址
 * @returns {Object} 执行结果
 */
async function executeSQL(sql, userId, username, ipAddress) {
  // 1. 安全检查
  validateSQL(sql)

  const startTime = Date.now()

  try {
    // 2. 记录操作日志（执行前）
    await operationLogger.log({
      userId,
      username,
      action: '执行SQL',
      resource: 'database',
      details: sql,
      ipAddress,
    })

    // 3. 执行 SQL
    const result = await pool.query(sql)

    const executionTime = Date.now() - startTime

    // 4. 记录成功日志
    await operationLogger.log({
      userId,
      username,
      action: 'SQL执行成功',
      resource: 'database',
      details: `执行时间: ${executionTime}ms`,
      ipAddress,
    })

    // 5. 返回结果
    if (isSelectStatement(sql)) {
      // SELECT 语句：返回查询结果
      let rows = result.rows || []
      
      // 限制返回行数
      if (rows.length > 500) {
        rows = rows.slice(0, 500)
      }

      return {
        type: 'SELECT',
        columns: result.fields ? result.fields.map(f => f.name) : [],
        rows: rows,
        total: result.rowCount || 0,
        executionTime,
        message: `查询成功，返回 ${rows.length} 条记录`,
      }
    } else {
      // 非 SELECT 语句：返回影响行数
      return {
        type: 'NON_SELECT',
        affectedRows: result.rowCount || 0,
        executionTime,
        message: `执行成功，影响 ${result.rowCount || 0} 行`,
      }
    }
  } catch (err) {
    // 记录失败日志
    await operationLogger.log({
      userId,
      username,
      action: 'SQL执行失败',
      resource: 'database',
      details: `错误: ${err.message}`,
      ipAddress,
      status: 'error',
    })

    throw new Error(`SQL 执行失败: ${err.message}`)
  }
}

/**
 * SQL 安全验证
 * @param {string} sql - SQL 语句
 */
function validateSQL(sql) {
  const upperSQL = sql.toUpperCase().trim()

  // 1. 禁止执行多条语句（检测多个分号）
  const semicolonCount = (sql.match(/;/g) || []).length
  if (semicolonCount > 1) {
    throw new Error('安全限制：禁止执行多条 SQL 语句')
  }

  // 2. 生产环境安全限制
  const isProduction = process.env.NODE_ENV === 'production'
  
  if (isProduction) {
    // 禁止 DROP
    if (upperSQL.startsWith('DROP')) {
      throw new Error('安全限制：生产环境禁止执行 DROP 语句')
    }

    // 禁止 TRUNCATE
    if (upperSQL.startsWith('TRUNCATE')) {
      throw new Error('安全限制：生产环境禁止执行 TRUNCATE 语句')
    }

    // 禁止 DELETE 无 WHERE 条件
    if (upperSQL.startsWith('DELETE') && !upperSQL.includes('WHERE')) {
      throw new Error('安全限制：DELETE 语句必须包含 WHERE 条件')
    }

    // 禁止 ALTER
    if (upperSQL.startsWith('ALTER')) {
      throw new Error('安全限制：生产环境禁止执行 ALTER 语句')
    }

    // 禁止 CREATE USER
    if (upperSQL.includes('CREATE USER')) {
      throw new Error('安全限制：禁止执行 CREATE USER 语句')
    }

    // 禁止 GRANT
    if (upperSQL.includes('GRANT')) {
      throw new Error('安全限制：禁止执行 GRANT 语句')
    }

    // 禁止 REVOKE
    if (upperSQL.includes('REVOKE')) {
      throw new Error('安全限制：禁止执行 REVOKE 语句')
    }
  }

  // 3. 基本 SQL 注入检测（简单检测）
  const dangerousPatterns = [
    /;\s*DROP\s/i,
    /;\s*DELETE\s/i,
    /;\s*UPDATE\s/i,
    /;\s*INSERT\s/i,
    /;\s*ALTER\s/i,
    /;\s*TRUNCATE\s/i,
  ]

  for (const pattern of dangerousPatterns) {
    if (pattern.test(sql)) {
      throw new Error('安全限制：检测到可疑的 SQL 注入模式')
    }
  }

  return true
}

/**
 * 判断是否为 SELECT 语句
 * @param {string} sql - SQL 语句
 * @returns {boolean}
 */
function isSelectStatement(sql) {
  const upperSQL = sql.toUpperCase().trim()
  return upperSQL.startsWith('SELECT') || upperSQL.startsWith('WITH')
}

module.exports = {
  executeSQL,
  validateSQL,
  isSelectStatement,
  exportDatabase,
  getTableList,
  getTableStructure,
}

/**
 * 导出数据库为 zip 文件
 * @param {string} userId - 用户ID
 * @param {string} username - 用户名
 * @param {string} ipAddress - IP地址
 * @returns {Object} 包含 zip 文件路径和文件名
 */
async function exportDatabase(userId, username, ipAddress) {
  const startTime = Date.now()
  const timestamp = new Date().toISOString().split('T')[0] // YYYY-MM-DD
  const tempDir = path.join(__dirname, '../../../temp')
  const sqlFileName = `db_backup_${timestamp}.sql`
  const zipFileName = `db_backup_${timestamp}.zip`
  const sqlFilePath = path.join(tempDir, sqlFileName)
  const zipFilePath = path.join(tempDir, zipFileName)

  try {
    // 1. 记录操作日志（导出开始）
    await operationLogger.log({
      userId,
      username,
      action: '导出数据库',
      resource: 'database',
      details: `开始导出数据库`,
      ipAddress,
    })

    // 2. 确保临时目录存在
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true })
    }

    // 3. 使用 pg_dump 导出数据库
    const dbConfig = {
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || '5432',
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASSWORD,
      dbname: process.env.DB_NAME || 'ai_agent_platform',
    }

    const dumpCommand = `PGPASSWORD=${dbConfig.password} pg_dump -h ${dbConfig.host} -p ${dbConfig.port} -U ${dbConfig.user} -d ${dbConfig.dbname} -f ${sqlFilePath}`

    console.log('执行 pg_dump 命令:', dumpCommand.replace(dbConfig.password, '***'))

    await execPromise(dumpCommand)

    // 4. 验证 SQL 文件是否生成
    if (!fs.existsSync(sqlFilePath)) {
      throw new Error('数据库导出失败：SQL文件未生成')
    }

    // 5. 将 SQL 文件压缩为 zip
    await compressToZip(sqlFilePath, zipFilePath)

    // 6. 删除临时 SQL 文件
    fs.unlinkSync(sqlFilePath)

    const exportTime = Date.now() - startTime

    // 7. 记录成功日志
    await operationLogger.log({
      userId,
      username,
      action: '数据库导出成功',
      resource: 'database',
      details: `导出时间: ${exportTime}ms, 文件大小: ${getFileSize(zipFilePath)}`,
      ipAddress,
    })

    return {
      filePath: zipFilePath,
      fileName: zipFileName,
      exportTime,
      message: '数据库导出成功',
    }
  } catch (err) {
    // 清理临时文件
    if (fs.existsSync(sqlFilePath)) {
      fs.unlinkSync(sqlFilePath)
    }
    if (fs.existsSync(zipFilePath)) {
      fs.unlinkSync(zipFilePath)
    }

    // 记录失败日志
    await operationLogger.log({
      userId,
      username,
      action: '数据库导出失败',
      resource: 'database',
      details: `错误: ${err.message}`,
      ipAddress,
      status: 'error',
    })

    throw new Error(`数据库导出失败: ${err.message}`)
  }
}

/**
 * 将文件压缩为 zip
 * @param {string} inputPath - 输入文件路径
 * @param {string} outputPath - 输出 zip 文件路径
 * @returns {Promise}
 */
function compressToZip(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputPath)
    const archive = archiver('zip', {
      zlib: { level: 9 }, // 最大压缩级别
    })

    output.on('close', () => {
      console.log(`压缩完成: ${archive.pointer()} total bytes`)
      resolve()
    })

    archive.on('error', (err) => {
      reject(err)
    })

    archive.pipe(output)
    archive.file(inputPath, { name: path.basename(inputPath) })
    archive.finalize()
  })
}

/**
 * 获取文件大小
 * @param {string} filePath - 文件路径
 * @returns {string} 格式化的文件大小
 */
function getFileSize(filePath) {
  const stats = fs.statSync(filePath)
  const bytes = stats.size
  
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i]
}

/**
 * 获取所有用户表名列表
 * @returns {Array} 表名数组
 */
async function getTableList() {
  try {
    const query = `
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE'
      ORDER BY table_name
    `
    
    const result = await pool.query(query)
    return result.rows.map(row => row.table_name)
  } catch (err) {
    console.error('获取表列表失败:', err)
    throw new Error(`获取表列表失败: ${err.message}`)
  }
}

/**
 * 获取指定表的字段结构
 * @param {string} tableName - 表名
 * @returns {Array} 字段结构数组
 */
async function getTableStructure(tableName) {
  if (!tableName) {
    throw new Error('表名不能为空')
  }

  try {
    // 防止 SQL 注入：验证表名只包含字母、数字、下划线
    if (!/^[a-zA-Z0-9_]+$/.test(tableName)) {
      throw new Error('无效的表名')
    }

    const query = `
      SELECT
        column_name,
        data_type,
        character_maximum_length,
        is_nullable,
        column_default,
        ordinal_position
      FROM information_schema.columns
      WHERE table_name = $1
        AND table_schema = 'public'
      ORDER BY ordinal_position
    `
    
    const result = await pool.query(query, [tableName])
    
    // 格式化返回数据
    return result.rows.map(row => ({
      column_name: row.column_name,
      data_type: row.data_type,
      character_maximum_length: row.character_maximum_length,
      is_nullable: row.is_nullable === 'YES' ? '是' : '否',
      column_default: row.column_default || '-',
      ordinal_position: row.ordinal_position,
    }))
  } catch (err) {
    console.error('获取表结构失败:', err)
    throw new Error(`获取表结构失败: ${err.message}`)
  }
}
