/**
 * 数据库管理 Controller
 * 路径：koa2/src/modules/database/controller.js
 */

const databaseService = require('./service')
const { success, error } = require('../../utils/response')
const fs = require('fs')

/**
 * 执行 SQL 语句
 * POST /api/database/execute
 */
async function executeSQL(ctx) {
  try {
    const { sql } = ctx.request.body

    // 参数验证
    if (!sql || !sql.trim()) {
      ctx.status = 400
      return error(ctx, 'SQL 语句不能为空')
    }

    // 获取用户信息
    const userId = ctx.state.user?.id
    const username = ctx.state.user?.username
    const ipAddress = ctx.ip || ctx.request.ip

    // 执行 SQL（包含安全检查和日志记录）
    const result = await databaseService.executeSQL(
      sql.trim(),
      userId,
      username,
      ipAddress
    )

    // 返回结果
    return success(ctx, result)
  } catch (err) {
    console.error('执行 SQL 失败:', err)
    return error(ctx, err.message || 'SQL 执行失败', 500)
  }
}

/**
 * 导出数据库
 * GET /api/database/export
 */
async function exportDatabase(ctx) {
  try {
    // 获取用户信息
    const userId = ctx.state.user?.id
    const username = ctx.state.user?.username
    const ipAddress = ctx.ip || ctx.request.ip

    // 执行导出
    const result = await databaseService.exportDatabase(userId, username, ipAddress)

    // 设置响应头
    ctx.set('Content-Type', 'application/zip')
    ctx.set('Content-Disposition', `attachment; filename="${result.fileName}"`)

    // 读取文件并流式传输
    const fileStream = fs.createReadStream(result.filePath)
    ctx.body = fileStream

    // 文件传输完成后删除临时文件
    fileStream.on('end', () => {
      fs.unlinkSync(result.filePath)
      console.log(`临时文件已删除: ${result.filePath}`)
    })

    fileStream.on('error', (err) => {
      console.error('文件流错误:', err)
      // 如果发生错误，也要删除文件
      if (fs.existsSync(result.filePath)) {
        fs.unlinkSync(result.filePath)
      }
    })
  } catch (err) {
    console.error('导出数据库失败:', err)
    return error(ctx, err.message || '数据库导出失败', 500)
  }
}

/**
 * 获取所有表名列表
 * GET /api/database/tables
 */
async function getTableList(ctx) {
  try {
    const tables = await databaseService.getTableList()
    return success(ctx, tables)
  } catch (err) {
    console.error('获取表列表失败:', err)
    return error(ctx, err.message || '获取表列表失败', 500)
  }
}

/**
 * 获取指定表的结构
 * GET /api/database/tables/:name
 */
async function getTableStructure(ctx) {
  try {
    const { name } = ctx.params
    
    if (!name) {
      ctx.status = 400
      return error(ctx, '表名不能为空')
    }

    const structure = await databaseService.getTableStructure(name)
    return success(ctx, structure)
  } catch (err) {
    console.error('获取表结构失败:', err)
    return error(ctx, err.message || '获取表结构失败', 500)
  }
}

module.exports = {
  executeSQL,
  exportDatabase,
  getTableList,
  getTableStructure,
}
